<?php
/**
 * Plugin Name: Δυσπρόσιτες Courier
 * Description: Ανεξάρτητα προφίλ courier, λίστες δυσπρόσιτων και κανόνες αποστολής για WooCommerce.
 * Author: Aboutnet
 * Author URI: https://aboutnet.gr/
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: disprosites-perioxes
 */
defined( 'ABSPATH' ) || exit;
define( 'DCP_VERSION', '1.0.0' );
define( 'DCP_FILE', __FILE__ );
define( 'DCP_PATH', plugin_dir_path( __FILE__ ) );
require_once DCP_PATH . 'includes/class-dcp-areas.php';
require_once DCP_PATH . 'includes/class-dcp-area-store.php';
require_once DCP_PATH . 'includes/class-dcp-profiles.php';
require_once DCP_PATH . 'includes/class-dcp-plugin.php';
add_action( 'plugins_loaded', array( 'DCP_Plugin', 'boot' ), 20 );