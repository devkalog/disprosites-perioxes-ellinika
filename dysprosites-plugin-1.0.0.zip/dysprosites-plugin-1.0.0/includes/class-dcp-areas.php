<?php
defined( 'ABSPATH' ) || exit;

/** Shared parser for the editor, CSV import and checkout. */
final class DCP_Areas {
    public static function city( $value ) {
        $value = strtr( (string) $value, array(
            'ά' => 'α', 'έ' => 'ε', 'ή' => 'η', 'ί' => 'ι', 'ϊ' => 'ι', 'ΐ' => 'ι',
            'ό' => 'ο', 'ύ' => 'υ', 'ϋ' => 'υ', 'ΰ' => 'υ', 'ώ' => 'ω',
            'Ά' => 'Α', 'Έ' => 'Ε', 'Ή' => 'Η', 'Ί' => 'Ι', 'Ϊ' => 'Ι',
            'Ό' => 'Ο', 'Ύ' => 'Υ', 'Ϋ' => 'Υ', 'Ώ' => 'Ω', 'ς' => 'σ',
        ) );
        $value = preg_replace( '/\p{Mn}+/u', '', $value );
        $value = trim( preg_replace( '/\s+/u', ' ', $value ) );
        if ( function_exists( 'mb_strtoupper' ) ) {
            return mb_strtoupper( $value, 'UTF-8' );
        }
        return strtoupper( strtr( $value, array_combine(
            preg_split( '//u', 'αβγδεζηθικλμνξοπρστυφχψω', -1, PREG_SPLIT_NO_EMPTY ),
            preg_split( '//u', 'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ', -1, PREG_SPLIT_NO_EMPTY )
        ) ) );
    }

    public static function postcode( $value ) {
        return strtoupper( preg_replace( '/\s+/u', '', (string) $value ) );
    }

    public static function parse( $text ) {
        $result = array( 'rows' => array(), 'errors' => array(), 'skipped' => array(), 'text' => '' );
        $text = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
        if ( 1 !== preg_match( '//u', $text ) ) {
            $result['errors'][] = 'Η λίστα πρέπει να έχει κωδικοποίηση UTF-8.';
            return $result;
        }
        $seen = array();
        foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $index => $line ) {
            if ( '' === trim( $line ) ) {
                continue;
            }
            $csv_field = '(?:[^",\r\n]*|"(?:[^"]|"")*")';
            if ( ! preg_match( '/^' . $csv_field . '(?:,' . $csv_field . ')*$/D', $line ) ) {
                $result['errors'][] = sprintf( 'Γραμμή %d: μη έγκυρα εισαγωγικά CSV.', $index + 1 );
                continue;
            }
            $fields = array_map( 'trim', str_getcsv( $line, ',', '"', '' ) );
            if ( empty( $result['rows'] ) && (
                array( 'city', 'postcode' ) === array_map( 'strtolower', $fields )
            ) ) {
                continue;
            }
            $city = '';
            $postcode = '';
            if ( 2 === count( $fields ) ) {
                list( $city, $postcode ) = $fields;
            }
            $city = self::city( $city );
            $postcode = self::postcode( $postcode );
            $valid_columns = 2 === count( $fields );
            if ( $valid_columns && ( '' === $postcode || '' === $city ) ) {
                $missing = '' === $postcode ? ( '' === $city ? 'πόλη και ΤΚ' : 'ΤΚ' ) : 'πόλη';
                $result['skipped'][] = array( 'line' => $index + 1, 'entry' => $line, 'missing' => $missing );
                continue;
            }
            if ( ! $valid_columns || ! preg_match( '/^[A-Z0-9]+(?:-[A-Z0-9]+)*$/D', $postcode ) ||
                preg_match( '/[<>\x00-\x1F]/u', $city ) ) {
                $result['errors'][] = sprintf( 'Γραμμή %d: αναμένεται Πόλη,ΤΚ.', $index + 1 );
                continue;
            }
            $key = $city . '|' . $postcode;
            if ( isset( $seen[ $key ] ) ) {
                continue;
            }
            $seen[ $key ] = true;
            $result['rows'][] = array( 'city' => $city, 'postcode' => $postcode );
        }
        $stream = fopen( 'php://temp', 'r+' );
        foreach ( $result['rows'] as $row ) {
            fputcsv( $stream, array( $row['city'], $row['postcode'] ), ',', '"', '' );
        }
        rewind( $stream );
        $result['text'] = rtrim( stream_get_contents( $stream ), "\r\n" );
        fclose( $stream );
        return $result;
    }

    public static function matches( $profile, $destination ) {
        if ( strtoupper( (string) ( $destination['country'] ?? '' ) ) !== $profile['country'] ) {
            return false;
        }
        $postcode = self::postcode( $destination['postcode'] ?? '' );
        $city = self::city( $destination['city'] ?? '' );
        if ( '' === $postcode || '' === $city ) {
            return false;
        }
        if ( empty( $profile['id'] ) || empty( $profile['area_generation'] ) ) {
            return false;
        }
        return DCP_Area_Store::matches( $profile['id'], $profile['area_generation'], $city, $postcode );
    }
}