<?php
/** Administration screens for courier profiles. */
defined( 'ABSPATH' ) || exit;

class DCP_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_dcp_save_profile', array( $this, 'save' ) );
		add_action( 'admin_post_dcp_delete_profile', array( $this, 'delete' ) );
		add_action( 'admin_post_dcp_export_profile', array( $this, 'export' ) );
		add_action( 'admin_post_dcp_import_legacy', array( $this, 'import_legacy' ) );
	}

	public function menu() {
		add_submenu_page( 'woocommerce', 'Δυσπρόσιτες περιοχές Courier', 'Courier – Δυσπρόσιτες', 'manage_woocommerce', 'dcp-couriers', array( $this, 'page' ) );
	}

	private function authorize( $action, $post = false ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html( 'Δεν έχετε δικαίωμα διαχείρισης των courier.' ), '', array( 'response' => 403 ) );
		}
		if ( $post && ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) ) {
			wp_die( esc_html( 'Μη επιτρεπτή μέθοδος αιτήματος.' ), '', array( 'response' => 405 ) );
		}
		check_admin_referer( $action );
	}

	private function url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'dcp-couriers' ), $args ), admin_url( 'admin.php' ) );
	}

	private function redirect( $notice ) {
		wp_safe_redirect( $this->url( array( 'dcp_notice' => $notice ) ) );
		exit;
	}

	private function request_id( $source ) {
		return isset( $source['profile_id'] ) && is_scalar( $source['profile_id'] ) ? sanitize_key( wp_unslash( (string) $source['profile_id'] ) ) : '';
	}

	public function page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html( 'Δεν έχετε δικαίωμα πρόσβασης.' ) );
		}
		$token = isset( $_GET['dcp_submission'] ) && is_string( $_GET['dcp_submission'] ) ? sanitize_key( wp_unslash( $_GET['dcp_submission'] ) ) : '';
		if ( $token ) {
			$key = 'dcp_submission_' . get_current_user_id() . '_' . $token;
			$state = get_transient( $key );
			delete_transient( $key );
			if ( is_array( $state ) ) {
				$this->form( $state['profile'], $state['id'], $state['errors'], $state['message'], $state['skipped'] );
			} else {
				$this->listing( array( 'Η προσωρινή φόρμα έχει λήξει ή έχει ήδη προβληθεί. Ανοίξτε ξανά το προφίλ. Οι αποθηκευμένες ρυθμίσεις δεν επηρεάζονται.' ) );
			}
			return;
		}
		$view = isset( $_GET['view'] ) && is_string( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : '';
		if ( 'new' === $view ) {
			$this->form( DCP_Profiles::defaults(), '' );
			return;
		}
		if ( 'edit' === $view ) {
			$id      = $this->request_id( $_GET );
			$profile = DCP_Profiles::get( $id );
			if ( is_wp_error( $profile ) ) {
				$this->listing( $profile->get_error_messages() );
				return;
			}
			if ( null === $profile ) {
				$this->listing( array( 'Το προφίλ δεν βρέθηκε.' ) );
				return;
			}
			$this->form( $profile, $id );
			return;
		}
		$this->listing();
	}

	private function notices( $errors = array(), $message = '', $skipped = array() ) {
		if ( function_exists( 'custom_elta_courier_method_init' ) || function_exists( 'custom_acs_method_init' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html( 'Το παλαιό snippet ΕΛΤΑ Courier είναι ακόμη ενεργό. Απενεργοποιήστε το ώστε να μη δημιουργούνται διπλές μέθοδοι ή συγκρούσεις με τα νέα προφίλ.' ) . '</p></div>';
		}
		if ( 'yes' === get_option( 'woocommerce_shipping_hide_rates_when_free', 'no' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html( 'Η ρύθμιση WooCommerce για απόκρυψη άλλων χρεώσεων όταν υπάρχει δωρεάν αποστολή είναι ενεργή. Το WooCommerce μπορεί να αφαιρέσει τις χρεώσεις courier πριν εφαρμοστούν οι κανόνες του πρόσθετου. Απενεργοποιήστε τη ρύθμιση αν πρέπει να εμφανίζεται ο courier δυσπρόσιτων περιοχών ή να αποκρύπτεται η δωρεάν αποστολή μέσω του προφίλ.' ) . '</p></div>';
		}
		foreach ( array_slice( $errors, 0, 10 ) as $error ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
		}
		if ( count( $errors ) > 10 ) {
			echo '<div class="notice notice-error"><p>' . esc_html( 'Εμφανίζονται τα πρώτα 10 σφάλματα. Διορθώστε τα και ελέγξτε ξανά τη λίστα.' ) . '</p></div>';
		}
		if ( $message ) {
			echo '<div class="notice notice-success"><p>' . esc_html( $message ) . '</p></div>';
		}
		if ( $skipped ) {
			echo '<div class="notice notice-warning"><p>' . esc_html( sprintf( 'Παραλείφθηκαν %d εγγραφές επειδή λείπει η πόλη ή/και ο ΤΚ. Δεν περιλαμβάνονται στην καθαρισμένη λίστα.', count( $skipped ) ) ) . '</p><details><summary>Εμφάνιση εγγραφών που παραλείφθηκαν</summary><ul>';
			foreach ( $skipped as $row ) {
				echo '<li>' . esc_html( sprintf( 'Γραμμή %d: %s — λείπει: %s.', $row['line'], $row['entry'], $row['missing'] ) ) . '</li>';
			}
			echo '</ul></details></div>';
		}
	}

	private function listing( $errors = array() ) {
		$messages = array(
			'saved'    => 'Το προφίλ αποθηκεύτηκε.',
			'deleted'  => 'Το προφίλ διαγράφηκε.',
			'migrated' => 'Η εισαγωγή των παλαιών ρυθμίσεων ολοκληρώθηκε. Ελέγξτε το νέο προφίλ και ορίστε τις μεθόδους προς απόκρυψη. Κανόνες μέσα σε παλιό PHP κώδικα, δωρεάν αποστολή και σειρά εμφάνισης δεν μεταφέρονται αυτόματα.',
			'noimport' => 'Δεν έγινε εισαγωγή. Οι παλαιές ρυθμίσεις μπορεί να έχουν ήδη εισαχθεί, να μην είναι διαθέσιμες ή να περιέχουν μη έγκυρη λίστα περιοχών ή άλλα μη έγκυρα στοιχεία. Ελέγξτε τις παλαιές ρυθμίσεις ή δημιουργήστε νέο προφίλ και εισαγάγετε τη λίστα για έλεγχο.',
		);
		$notice = isset( $_GET['dcp_notice'] ) && is_string( $_GET['dcp_notice'] ) ? sanitize_key( $_GET['dcp_notice'] ) : '';
		echo '<div class="wrap"><h1 class="wp-heading-inline">Courier – Δυσπρόσιτες περιοχές</h1> ';
		echo '<a class="page-title-action" href="' . esc_url( $this->url( array( 'view' => 'new' ) ) ) . '">Νέο προφίλ courier</a><hr class="wp-header-end">';
		$this->notices( $errors, isset( $messages[ $notice ] ) ? $messages[ $notice ] : '' );
		echo '<p>Διαχειριστείτε ανεξάρτητα τις περιοχές, τις χρεώσεις και τις μεθόδους που αποκρύπτει κάθε courier. Δεν απαιτείται προσθήκη της μεθόδου courier στις ζώνες αποστολής.</p>';
		echo '<table class="wp-list-table widefat fixed striped"><thead><tr><th>Όνομα διαχείρισης</th><th>Τίτλος στο ταμείο</th><th>Κατάσταση</th><th>Ενέργειες</th></tr></thead><tbody>';
		$profiles = DCP_Profiles::all();
		if ( ! $profiles ) {
			echo '<tr><td colspan="4">Δεν υπάρχουν προφίλ courier. Δημιουργήστε το πρώτο προφίλ.</td></tr>';
		}
		foreach ( $profiles as $id => $profile ) {
			$edit = $this->url( array( 'view' => 'edit', 'profile_id' => $id ) );
			echo '<tr><td><strong><a href="' . esc_url( $edit ) . '">' . esc_html( $profile['name'] ) . '</a></strong><br><code>' . esc_html( $id ) . '</code></td>';
			echo '<td>' . esc_html( $profile['title'] ) . '</td><td>' . esc_html( 'yes' === $profile['enabled'] ? 'Ενεργό' : 'Ανενεργό' ) . '</td><td>';
			echo '<a class="button button-small" href="' . esc_url( $edit ) . '">Επεξεργασία</a> ';
			echo '<a class="button button-small" href="' . esc_url( $this->export_url( $id ) ) . '">Εξαγωγή CSV</a>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="dcp_delete_profile"><input type="hidden" name="profile_id" value="' . esc_attr( $id ) . '">';
			wp_nonce_field( 'dcp_delete_profile_' . $id );
			echo '<p><label><input type="checkbox" name="confirm_delete" value="yes" required> Επιβεβαίωση διαγραφής</label> <button class="button button-small" type="submit">Διαγραφή</button></p></form></td></tr>';
		}
		echo '</tbody></table>';
		$imports = DCP_Profiles::legacy_imports();
		foreach ( DCP_Profiles::legacy_sources() as $source => $name ) {
			if ( false === get_option( 'woocommerce_' . $source . '_settings', false ) ) {
				continue;
			}
			echo '<h2>' . esc_html( 'Εισαγωγή παλαιών ρυθμίσεων ' . $name ) . '</h2>';
			if ( isset( $imports[ $source ] ) ) {
				echo '<p>Έχει ήδη γίνει εισαγωγή αυτής της πηγής. Δεν θα δημιουργηθεί δεύτερο προφίλ.</p>';
				continue;
			}
			echo '<p>Οι παλαιές ρυθμίσεις διατηρούνται. Μεταφέρονται λίστα, τίτλος και χρεώσεις. Ορίστε χειροκίνητα τις μεθόδους προς απόκρυψη: κανόνες PHP δεν ανακτώνται από τη βάση.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="dcp_import_legacy">';
			echo '<input type="hidden" name="legacy_source" value="' . esc_attr( $source ) . '">';
			wp_nonce_field( 'dcp_import_legacy' );
			echo '<button class="button" type="submit">Εισαγωγή παλαιών ρυθμίσεων</button></form>';
		}
		echo '</div>';
	}

	private function export_url( $id ) {
		return wp_nonce_url( add_query_arg( array( 'action' => 'dcp_export_profile', 'profile_id' => $id ), admin_url( 'admin-post.php' ) ), 'dcp_export_profile_' . $id );
	}

	private function text_field( $key, $label, $value, $description = '', $type = 'text' ) {
		echo '<tr><th scope="row"><label for="dcp-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="dcp-' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '"' . ( 'number' === $type ? ' min="0" step="any"' : '' ) . '>';
		if ( $description ) {
			echo '<p class="description">' . esc_html( $description ) . '</p>';
		}
		echo '</td></tr>';
	}

	private function form( $profile, $id, $errors = array(), $message = '', $skipped = array() ) {
		$p = array_merge( DCP_Profiles::defaults(), $profile );
		echo '<div class="wrap"><h1>' . esc_html( $id ? 'Επεξεργασία courier' : 'Νέο προφίλ courier' ) . '</h1>';
		$this->notices( $errors, $message, $skipped );
		echo '<p><a href="' . esc_url( $this->url() ) . '">← Όλα τα προφίλ</a></p>';
		echo '<p>Το προφίλ εφαρμόζεται βάσει των περιοχών του, χωρίς να απαιτείται προσθήκη της μεθόδου courier στις ζώνες αποστολής.</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="dcp_save_profile"><input type="hidden" name="profile_id" value="' . esc_attr( $id ) . '">';
		wp_nonce_field( 'dcp_save_profile_' . $id );
		echo '<table class="form-table" role="presentation">';
		$this->text_field( 'name', 'Όνομα διαχείρισης', $p['name'], 'Εσωτερικό όνομα για να ξεχωρίζετε τα προφίλ courier.' );
		$this->text_field( 'title', 'Τίτλος στο ταμείο', $p['title'] );
		echo '<tr><th scope="row">Ενεργοποίηση</th><td><label><input type="checkbox" name="enabled" value="yes" ' . checked( $p['enabled'], 'yes', false ) . '> Ενεργό προφίλ</label></td></tr>';
		echo '<tr><th scope="row"><label for="dcp-country">Χώρα</label></th><td><select id="dcp-country" name="country"><option value="GR">Ελλάδα (GR)</option></select></td></tr>';
		echo '<tr><th scope="row"><label for="dcp-areas">Περιοχές</label></th><td><textarea class="large-text code" rows="12" id="dcp-areas" name="areas">' . esc_textarea( $p['areas'] ) . '</textarea><p class="description">Μία εγγραφή ανά γραμμή: Πόλη,12345. Υποστηρίζεται κεφαλίδα CSV city,postcode. Εγγραφές με κενή πόλη ή ΤΚ παραλείπονται με ειδοποίηση. Άλλα σφάλματα αποτρέπουν την αποθήκευση. Αν η παλιά λίστα περιέχει μόνο ΤΚ, εισαγάγετε ξανά την πλήρη λίστα με τις πόλεις.</p></td></tr>';
		echo '<tr><th scope="row"><label for="dcp-csv">Εισαγωγή περιοχών CSV</label></th><td><input type="file" id="dcp-csv" name="areas_csv" accept=".csv,text/csv"><p class="description">Αρχείο UTF-8, έως 2 MB. Η εισαγωγή αντικαθιστά το παραπάνω κείμενο μόνο στην προεπισκόπηση· δεν αποθηκεύει το προφίλ. Έπειτα ελέγξτε και πατήστε «Αποθήκευση προφίλ».</p><button class="button" type="submit" name="operation" value="import" formnovalidate>Φόρτωση CSV στο πεδίο περιοχών</button></td></tr>';
		$this->text_field( 'base_cost', 'Βασικό κόστος', $p['base_cost'], 'Ποσό στο νόμισμα του καταστήματος, χωρίς φόρο. Όταν επιλέγεται «Φορολογητέο», ο φόρος αποστολής υπολογίζεται από το WooCommerce βάσει των ρυθμίσεων του καταστήματος.', 'number' );
		$this->text_field( 'base_weight', 'Βασικό βάρος (kg)', $p['base_weight'], 'Βάρος που καλύπτει το βασικό κόστος, σε κιλά.', 'number' );
		$this->text_field( 'additional_cost', 'Επιπλέον κόστος ανά kg', $p['additional_cost'], 'Χρέωση χωρίς φόρο για βάρος πάνω από το βασικό όριο.', 'number' );
		$this->text_field( 'free_shipping_threshold', 'Δωρεάν μεταφορικά από', $p['free_shipping_threshold'], 'Ποσό στο νόμισμα του καταστήματος (π.χ. 45). Ισχύει για αυτόν τον courier όταν η αξία προϊόντων ολόκληρου του καλαθιού, μετά από εκπτώσεις/κουπόνια και μαζί με τον ΦΠΑ, είναι ίση ή μεγαλύτερη από το όριο. Δεν περιλαμβάνονται μεταφορικά ή πρόσθετα τέλη. Κενό = απενεργοποιημένο, 0 = πάντα δωρεάν για τις περιοχές αυτού του προφίλ.', 'number' );
		$this->text_field( 'free_shipping_title', 'Τίτλος όταν τα μεταφορικά είναι δωρεάν', $p['free_shipping_title'], 'Τίτλος μεθόδου στο checkout όταν ενεργοποιείται το όριο δωρεάν μεταφορικών αυτού του courier (π.χ. ACS – Δωρεάν αποστολή). Αν μείνει κενό, χρησιμοποιείται ο κανονικός τίτλος στο ταμείο.' );
		echo '<tr><th scope="row"><label for="dcp-tax">Φορολογική κατάσταση</label></th><td><select id="dcp-tax" name="tax_status"><option value="taxable" ' . selected( $p['tax_status'], 'taxable', false ) . '>Φορολογητέο</option><option value="none" ' . selected( $p['tax_status'], 'none', false ) . '>Χωρίς φόρο</option></select></td></tr>';
		echo '<tr><th scope="row">Απόκρυψη μεθόδων ζωνών</th><td><p class="description">Οι επιλεγμένες μέθοδοι αποκρύπτονται όταν εφαρμόζεται αυτό το προφίλ. Η ίδια η μέθοδος courier εξαιρείται.</p>';
		$options  = $this->shipping_options();
		$selected = (array) $p['hide_instances'];
		foreach ( $options as $key => $label ) {
			echo '<p><label><input type="checkbox" name="hide_instances[]" value="' . esc_attr( $key ) . '" ' . checked( in_array( $key, $selected, true ), true, false ) . '> ' . esc_html( $label ) . ' <code>' . esc_html( $key ) . '</code></label></p>';
		}
		foreach ( array_diff( $selected, array_keys( $options ) ) as $key ) {
			if ( 0 === strpos( $key, 'dcp_courier:' ) ) {
				continue;
			}
			echo '<p><label><input type="checkbox" name="hide_instances[]" value="' . esc_attr( $key ) . '" checked> ' . esc_html( 'Μη διαθέσιμη πλέον μέθοδος: ' . $key ) . '</label></p>';
		}
		if ( ! $options ) {
			echo '<p>Δεν βρέθηκαν άλλες μέθοδοι στις ζώνες αποστολής.</p>';
		}
		echo '</td></tr><tr><th scope="row"><label for="dcp-hide-rates">Ακριβή IDs τρίτων μεθόδων</label></th><td><textarea class="large-text code" rows="5" id="dcp-hide-rates" name="hide_rates">' . esc_textarea( implode( "\n", (array) $p['hide_rates'] ) ) . '</textarea><p class="description">Ένα πλήρες rate ID ανά γραμμή (π.χ. flat_rate:3). Μόνο ακριβής αντιστοίχιση, χωρίς μπαλαντέρ. Μην προσθέτετε τη μέθοδο dcp_courier.</p></td></tr></table>';
		echo '<p class="submit"><button type="submit" name="operation" value="save" class="button button-primary">Αποθήκευση προφίλ</button> <a class="button" href="' . esc_url( $this->url() ) . '">Ακύρωση</a>';
		if ( $id ) {
			echo ' <a class="button" href="' . esc_url( $this->export_url( $id ) ) . '">Εξαγωγή αποθηκευμένων περιοχών CSV</a>';
		}
		echo '</p></form></div>';
	}

	private function shipping_options() {
		$options = array();
		if ( ! class_exists( 'WC_Shipping_Zones' ) ) {
			return $options;
		}
		$zones   = WC_Shipping_Zones::get_zones();
		$zones[] = array( 'zone_id' => 0, 'zone_name' => 'Τοποθεσίες που δεν καλύπτονται από άλλες ζώνες' );
		foreach ( $zones as $zone_data ) {
			$zone = new WC_Shipping_Zone( $zone_data['zone_id'] );
			foreach ( $zone->get_shipping_methods( false ) as $method ) {
				if ( 'dcp_courier' === $method->id ) {
					continue;
				}
				$key             = $method->id . ':' . $method->get_instance_id();
				$options[ $key ] = $zone_data['zone_name'] . ' — ' . $method->get_title();
			}
		}
		return $options;
	}

	private function submitted_profile() {
		$raw = array();
		foreach ( array( 'name', 'title', 'country', 'areas', 'base_cost', 'base_weight', 'additional_cost', 'tax_status', 'free_shipping_threshold', 'free_shipping_title' ) as $field ) {
			$raw[ $field ] = isset( $_POST[ $field ] ) && is_string( $_POST[ $field ] ) ? wp_unslash( $_POST[ $field ] ) : '';
		}
		$raw['enabled']        = isset( $_POST['enabled'] ) && 'yes' === $_POST['enabled'] ? 'yes' : 'no';
		$raw['hide_instances'] = array();
		if ( isset( $_POST['hide_instances'] ) && is_array( $_POST['hide_instances'] ) ) {
			foreach ( wp_unslash( $_POST['hide_instances'] ) as $value ) {
				if ( is_string( $value ) && 0 !== strpos( $value, 'dcp_courier:' ) ) {
					$raw['hide_instances'][] = $value;
				}
			}
		}
		$rates             = isset( $_POST['hide_rates'] ) && is_string( $_POST['hide_rates'] ) ? wp_unslash( $_POST['hide_rates'] ) : '';
		$raw['hide_rates'] = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $rates ) ), 'strlen' ) );
		return $raw;
	}

	/** Post/Redirect/Get: only admin.php renders the form, with the full admin menu. */
	private function render_submission( $profile, $id, $errors = array(), $message = '', $skipped = array() ) {
		$token = wp_generate_uuid4();
		$key = 'dcp_submission_' . get_current_user_id() . '_' . $token;
		$state = array( 'profile' => $profile, 'id' => $id, 'errors' => $errors, 'message' => $message, 'skipped' => $skipped );
		if ( ! set_transient( $key, $state, 15 * MINUTE_IN_SECONDS ) ) {
			wp_die( esc_html( 'Δεν ήταν δυνατή η προσωρινή αποθήκευση της φόρμας. Επιστρέψτε στην προηγούμενη σελίδα και δοκιμάστε ξανά.' ) );
		}
		wp_safe_redirect( $this->url( array( 'view' => $id ? 'edit' : 'new', 'profile_id' => $id, 'dcp_submission' => $token ) ), 303 );
		exit;
	}

	public function save() {
		$id = $this->request_id( $_POST );
		$this->authorize( 'dcp_save_profile_' . $id, true );
		$raw = $this->submitted_profile();
		$profiles = DCP_Profiles::all();
		if ( $id && ! isset( $profiles[ $id ] ) ) {
			$this->render_submission( $raw, '', array( 'Το προφίλ δεν υπάρχει πλέον. Μπορείτε να αποθηκεύσετε τα στοιχεία ως νέο προφίλ.' ) );
		}
		if ( isset( $_POST['operation'] ) && 'import' === $_POST['operation'] ) {
			$this->upload( $raw, $id );
		}
		// Do not silently ignore a file selected without using the preview button.
		if ( isset( $_FILES['areas_csv']['error'] ) && UPLOAD_ERR_NO_FILE !== (int) $_FILES['areas_csv']['error'] ) {
			$this->render_submission( $raw, $id, array( 'Έχετε επιλέξει αρχείο CSV. Πατήστε πρώτα «Φόρτωση CSV στο πεδίο περιοχών» και ελέγξτε το αποτέλεσμα.' ) );
		}
		if ( strlen( $raw['areas'] ) > 2 * 1024 * 1024 ) {
			$this->render_submission( $raw, $id, array( 'Η λίστα περιοχών δεν πρέπει να ξεπερνά τα 2 MB. Μειώστε το μέγεθός της και δοκιμάστε ξανά.' ) );
		}
		$parsed = DCP_Areas::parse( $raw['areas'] );
		if ( ! empty( $parsed['errors'] ) ) {
			$this->render_submission( $raw, $id, $parsed['errors'], '', $parsed['skipped'] );
		}
		$result = DCP_Profiles::save( $id, $raw );
		if ( is_wp_error( $result ) ) {
			$this->render_submission( $raw, $id, $result->get_error_messages(), '', $parsed['skipped'] );
		}
		if ( $parsed['skipped'] ) {
			$raw['areas'] = $parsed['text'];
			$this->render_submission( $raw, $result, array(), 'Το προφίλ αποθηκεύτηκε με τις έγκυρες εγγραφές.', $parsed['skipped'] );
		}
		$this->redirect( 'saved' );
	}

	private function upload( $raw, $id ) {
		$file = isset( $_FILES['areas_csv'] ) ? $_FILES['areas_csv'] : array();
		if ( ! isset( $file['error'], $file['tmp_name'], $file['name'] ) || is_array( $file['error'] ) || UPLOAD_ERR_OK !== (int) $file['error'] ) {
			$this->render_submission( $raw, $id, array( 'Η μεταφόρτωση απέτυχε ή δεν επιλέχθηκε αρχείο. Επιλέξτε CSV έως 2 MB και δοκιμάστε ξανά.' ) );
		}
		if ( ! is_string( $file['tmp_name'] ) || ! is_string( $file['name'] ) || ! is_uploaded_file( $file['tmp_name'] ) || 'csv' !== strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) ) ) {
			$this->render_submission( $raw, $id, array( 'Απαιτείται έγκυρο μεταφορτωμένο αρχείο .csv.' ) );
		}
		$size = filesize( $file['tmp_name'] );
		if ( false === $size || $size > 2 * 1024 * 1024 ) {
			$this->render_submission( $raw, $id, array( 'Το αρχείο CSV πρέπει να είναι έως 2 MB.' ) );
		}
		$text = file_get_contents( $file['tmp_name'] );
		if ( false === $text || 1 !== preg_match( '//u', $text ) || false !== strpos( $text, "\0" ) ) {
			$this->render_submission( $raw, $id, array( 'Το CSV πρέπει να είναι αρχείο κειμένου UTF-8. Αποθηκεύστε το με κωδικοποίηση UTF-8 και δοκιμάστε ξανά.' ) );
		}
		$raw['areas'] = $text;
		$parsed       = DCP_Areas::parse( $text );
		if ( ! empty( $parsed['errors'] ) ) {
			$this->render_submission( $raw, $id, array_merge( array( 'Το CSV περιέχει σφάλματα. Δεν αποθηκεύτηκε τίποτα· διορθώστε το κείμενο παρακάτω.' ), $parsed['errors'] ), '', $parsed['skipped'] );
		}
		$raw['areas'] = $parsed['text'];
		$this->render_submission( $raw, $id, array(), 'Το CSV φορτώθηκε στο πεδίο περιοχών. Δεν έχει αποθηκευτεί ακόμη το προφίλ. Ελέγξτε τα στοιχεία και πατήστε «Αποθήκευση προφίλ».', $parsed['skipped'] );
	}

	public function delete() {
		$id = $this->request_id( $_POST );
		$this->authorize( 'dcp_delete_profile_' . $id, true );
		if ( ! isset( $_POST['confirm_delete'] ) || 'yes' !== $_POST['confirm_delete'] ) {
			wp_die( esc_html( 'Απαιτείται ρητή επιβεβαίωση διαγραφής.' ) );
		}
		$result = DCP_Profiles::delete( $id );
		if ( is_wp_error( $result ) ) {
			$profile = DCP_Profiles::get( $id );
			$this->render_submission( is_array( $profile ) ? $profile : DCP_Profiles::defaults(), $id, $result->get_error_messages() );
		}
		$this->redirect( 'deleted' );
	}

	public function import_legacy() {
		$this->authorize( 'dcp_import_legacy', true );
		$source = isset( $_POST['legacy_source'] ) && is_string( $_POST['legacy_source'] ) ? sanitize_key( wp_unslash( $_POST['legacy_source'] ) ) : '';
		if ( ! array_key_exists( $source, DCP_Profiles::legacy_sources() ) ) {
			$this->redirect( 'noimport' );
		}
		$this->redirect( DCP_Profiles::migrate_legacy( $source ) ? 'migrated' : 'noimport' );
	}

	public function export() {
		$id = $this->request_id( $_GET );
		$this->authorize( 'dcp_export_profile_' . $id );
		$profile = DCP_Profiles::get( $id );
		if ( is_wp_error( $profile ) ) {
			wp_die( esc_html( $profile->get_error_message() ) );
		}
		if ( null === $profile ) {
			wp_die( esc_html( 'Το προφίλ δεν βρέθηκε.' ), '', array( 'response' => 404 ) );
		}
		$parsed = DCP_Areas::parse( $profile['areas'] );
		if ( ! empty( $parsed['errors'] ) ) {
			wp_die( esc_html( 'Οι αποθηκευμένες περιοχές περιέχουν σφάλματα. Διορθώστε το προφίλ πριν από την εξαγωγή.' ) );
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="courier-' . sanitize_file_name( $id ) . '.csv"' );
		header( 'X-Content-Type-Options: nosniff' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'city', 'postcode' ), ',', '"', '' );
		foreach ( $parsed['rows'] as $row ) {
			// Keep CSV exports safe when opened by spreadsheet applications.
			$cells = array( $row['city'], $row['postcode'] );
			foreach ( $cells as &$cell ) {
				if ( preg_match( '/^[\s]*[=+@\-]/u', $cell ) ) {
					$cell = "'" . $cell;
				}
			}
			unset( $cell );
			fputcsv( $out, $cells, ',', '"', '' );
		}
		fclose( $out );
		exit;
	}
}