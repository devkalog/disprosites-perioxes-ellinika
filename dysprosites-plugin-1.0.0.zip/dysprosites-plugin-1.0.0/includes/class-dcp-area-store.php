<?php
defined( 'ABSPATH' ) || exit;

/** Immutable area generations; callers own the active-generation option pointer. */
final class DCP_Area_Store {
    private static function table() {
        global $wpdb;
        return $wpdb->prefix . 'dcp_areas';
    }

    private static function valid_id( $id ) {
        return is_string( $id ) && 1 === preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/D', $id );
    }

    public static function ready(): bool {
        return '1' === get_option( 'dcp_area_schema' );
    }

    public static function install(): bool {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // A failed install must never leave a readiness marker behind.
        delete_option( 'dcp_area_schema' );
        $table = self::table();
        $collate = $wpdb->get_charset_collate();
        // All text columns inherit the same charset: wpdb can reject UTF-8 INSERTs
        // before SQL execution when ASCII identifier columns are mixed with UTF-8 city.
        dbDelta( "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            profile_id varchar(36) NOT NULL,
            generation varchar(36) NOT NULL,
            position bigint(20) unsigned NOT NULL,
            city longtext NOT NULL,
            postcode varchar(64) NOT NULL,
            match_hash char(64) NOT NULL,
            created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY profile_generation_hash (profile_id,generation,match_hash),
            KEY profile_generation_position (profile_id,generation,position)
        ) ENGINE=InnoDB {$collate};" );
        if ( '' !== $wpdb->last_error ) {
            return false;
        }
        $found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
        if ( '' !== $wpdb->last_error || $table !== $found ) {
            return false;
        }
        $indexes = $wpdb->get_results( "SHOW INDEX FROM {$table}", ARRAY_A );
        if ( '' !== $wpdb->last_error || ! is_array( $indexes ) ) {
            return false;
        }
        $columns = array();
        foreach ( $indexes as $index ) {
            $columns[ $index['Key_name'] ][ (int) $index['Seq_in_index'] ] = $index['Column_name'];
        }
        foreach ( array(
            'profile_generation_hash' => array( 'profile_id', 'generation', 'match_hash' ),
            'profile_generation_position' => array( 'profile_id', 'generation', 'position' ),
        ) as $name => $expected ) {
            if ( ! isset( $columns[ $name ] ) ) {
                return false;
            }
            ksort( $columns[ $name ] );
            if ( array_values( $columns[ $name ] ) !== $expected ) {
                return false;
            }
        }
        update_option( 'dcp_area_schema', '1', false );
        return self::ready();
    }

    /** Rows must already be normalized by the parser. Returns a UUID or WP_Error. */
    public static function stage( $profile_id, $rows ) {
        global $wpdb;
        if ( ! self::ready() || ! self::valid_id( $profile_id ) || ! is_array( $rows ) ) {
            return new WP_Error( 'dcp_area_stage', 'Μη έγκυρη κατάσταση αποθήκευσης περιοχών ή εταιρεία.' );
        }
        // Validate the entire input before writing, including varchar character limits.
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) || ! isset( $row['city'], $row['postcode'] ) ||
                ! is_string( $row['city'] ) || ! is_string( $row['postcode'] ) ||
                '' === $row['city'] || '' === $row['postcode'] ||
                1 !== preg_match( '//u', $row['city'] ) || strlen( $row['city'] ) > 4294967295 ||
                1 !== preg_match( '/^.{0,64}$/usD', $row['postcode'] ) ) {
                return new WP_Error( 'dcp_area_rows', 'Μη έγκυρη περιοχή ή ταχυδρομικός κώδικας μεγαλύτερος από 64 χαρακτήρες.' );
            }
        }
        $generation = wp_generate_uuid4();
        $table = self::table();
        // Never append to, or clean up, an existing generation even on UUID collision.
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE profile_id = %s AND generation = %s",
            $profile_id, $generation
        ) );
        if ( ! self::valid_id( $generation ) || '' !== $wpdb->last_error || null === $existing || 0 !== (int) $existing ) {
            return new WP_Error( 'dcp_area_generation', 'Δεν ήταν δυνατή η δημιουργία νέας έκδοσης περιοχών.' );
        }
        $position = 0;
        foreach ( array_chunk( $rows, 200 ) as $chunk ) {
            $values = array();
            $args = array();
            foreach ( $chunk as $row ) {
                $values[] = '(%s, %s, %d, %s, %s, %s)';
                array_push( $args, $profile_id, $generation, $position++, $row['city'], $row['postcode'], hash( 'sha256', $row['city'] . '|' . $row['postcode'] ) );
            }
            $inserted = $wpdb->query( $wpdb->prepare(
                "INSERT INTO {$table} (profile_id, generation, position, city, postcode, match_hash) VALUES " . implode( ', ', $values ),
                $args
            ) );
            if ( count( $chunk ) !== $inserted || '' !== $wpdb->last_error ) {
                $error = $wpdb->last_error;
                self::discard( $profile_id, $generation );
                return new WP_Error( 'dcp_area_insert', 'Δεν ήταν δυνατή η αποθήκευση όλων των περιοχών.', array( 'database_error' => $error ) );
            }
        }
        $count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE profile_id = %s AND generation = %s",
            $profile_id, $generation
        ) );
        if ( '' !== $wpdb->last_error || null === $count || count( $rows ) !== (int) $count ) {
            self::discard( $profile_id, $generation );
            return new WP_Error( 'dcp_area_count', 'Η επαλήθευση της έκδοσης περιοχών απέτυχε.' );
        }
        return $generation;
    }

    /** Fetch the whole generation only for administrative editing/export. */
    public static function text( $profile_id, $generation ) {
        global $wpdb;
        if ( ! self::ready() || ! self::valid_id( $profile_id ) || ! self::valid_id( $generation ) ) {
            return new WP_Error( 'dcp_area_read', 'Μη έγκυρη κατάσταση αποθήκευσης ή έκδοση περιοχών.' );
        }
        $table = self::table();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT city, postcode FROM {$table} WHERE profile_id = %s AND generation = %s ORDER BY position ASC",
            $profile_id, $generation
        ), ARRAY_A );
        if ( '' !== $wpdb->last_error || ! is_array( $rows ) ) {
            return new WP_Error( 'dcp_area_read', 'Δεν ήταν δυνατή η ανάγνωση των περιοχών.' );
        }
        $stream = fopen( 'php://temp', 'r+' );
        if ( false === $stream ) {
            return new WP_Error( 'dcp_area_csv', 'Δεν ήταν δυνατή η δημιουργία CSV περιοχών.' );
        }
        foreach ( $rows as $row ) {
            if ( false === fputcsv( $stream, array( $row['city'], $row['postcode'] ), ',', '"', '' ) ) {
                fclose( $stream );
                return new WP_Error( 'dcp_area_csv', 'Δεν ήταν δυνατή η εγγραφή CSV περιοχών.' );
            }
        }
        rewind( $stream );
        $text = stream_get_contents( $stream );
        fclose( $stream );
        return false === $text ? new WP_Error( 'dcp_area_csv', 'Δεν ήταν δυνατή η ανάγνωση CSV περιοχών.' ) : rtrim( $text, "\r\n" );
    }

    /** City and postcode must be normalized by the caller, exactly as for stage(). */
    public static function matches( $profile_id, $generation, $city, $postcode ): bool {
        global $wpdb;
        if ( ! self::ready() || ! self::valid_id( $profile_id ) || ! self::valid_id( $generation ) ||
            ! is_string( $city ) || ! is_string( $postcode ) ) {
            return false;
        }
        $table = self::table();
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT city, postcode FROM {$table} WHERE profile_id = %s AND generation = %s AND match_hash = %s LIMIT 1",
            $profile_id, $generation, hash( 'sha256', $city . '|' . $postcode )
        ), ARRAY_A );
        return '' === $wpdb->last_error && is_array( $row ) && $city === $row['city'] && $postcode === $row['postcode'];
    }

    public static function discard( $id, $generation ): bool {
        global $wpdb;
        if ( ! self::valid_id( $id ) || ! self::valid_id( $generation ) ) {
            return false;
        }
        return false !== $wpdb->delete( self::table(), array( 'profile_id' => $id, 'generation' => $generation ), array( '%s', '%s' ) );
    }

    /** Keep recent generations for in-flight readers of the previous option pointer. */
    public static function prune( $id, $keep_generation ): bool {
        global $wpdb;
        if ( ! self::valid_id( $id ) || ! self::valid_id( $keep_generation ) ) {
            return false;
        }
        $table = self::table();
        return false !== $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE profile_id = %s AND generation <> %s AND created_at < (CURRENT_TIMESTAMP - INTERVAL 1 DAY)", $id, $keep_generation
        ) );
    }

    public static function delete_profile( $id ): bool {
        global $wpdb;
        if ( ! self::valid_id( $id ) ) {
            return false;
        }
        return false !== $wpdb->delete( self::table(), array( 'profile_id' => $id ), array( '%s' ) );
    }
}