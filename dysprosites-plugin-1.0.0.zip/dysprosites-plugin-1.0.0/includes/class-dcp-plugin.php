<?php
defined( 'ABSPATH' ) || exit;

final class DCP_Plugin {
    public static function boot() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', array( __CLASS__, 'missing_woocommerce' ) );
            return;
        }
        if ( ! DCP_Profiles::migrate_options() ) {
            add_action( 'admin_notices', array( __CLASS__, 'storage_notice' ) );
        }
        add_action( 'woocommerce_shipping_init', array( __CLASS__, 'shipping_init' ) );
        add_filter( 'woocommerce_shipping_methods', array( __CLASS__, 'methods' ) );
        add_filter( 'woocommerce_package_rates', array( __CLASS__, 'filter_rates' ), 100, 2 );
        // The package hash must change even for existing customer sessions after edits.
        add_filter( 'woocommerce_cart_shipping_packages', array( __CLASS__, 'package_revision' ) );
        if ( is_admin() ) {
            require_once DCP_PATH . 'includes/class-dcp-admin.php';
            new DCP_Admin();
        }
    }

    public static function missing_woocommerce() {
        if ( current_user_can( 'activate_plugins' ) ) {
            echo '<div class="notice notice-error"><p>Το Δυσπρόσιτες Courier απαιτεί ενεργό WooCommerce.</p></div>';
        }
    }

    public static function storage_notice() {
        if ( current_user_can( 'manage_woocommerce' ) ) {
            echo '<div class="notice notice-error"><p>Δυσπρόσιτες Courier: η μεταφορά των λιστών στον πίνακα περιοχών δεν ολοκληρώθηκε. Τα αρχικά δεδομένα διατηρούνται. Ελέγξτε τη βάση ή ανοίξτε και αποθηκεύστε τις λίστες με μη έγκυρες/ελλιπείς εγγραφές. Μη μεταφερμένα προφίλ δεν δίνουν χρέωση δυσπρόσιτης· μην χρησιμοποιήσετε το checkout πριν διορθωθεί.</p></div>';
        }
    }

    public static function shipping_init() {
        require_once DCP_PATH . 'includes/class-dcp-shipping-method.php';
    }

    public static function methods( $methods ) {
        self::shipping_init();
        $methods['dcp_courier'] = 'DCP_Shipping_Method';
        return $methods;
    }

    public static function package_revision( $packages ) {
        $revision = get_option( 'dcp_shipping_revision', 'initial' );
        self::shipping_init();
        $amount = DCP_Shipping_Method::cart_amount();
        foreach ( $packages as &$package ) {
            $package['dcp_revision'] = DCP_VERSION . ':indexed-v1:free-cart-v1:' . $revision;
            // A virtual item or another package can cross the threshold too.
            $package['dcp_cart_amount'] = $amount;
        }
        unset( $package );
        return $packages;
    }

    public static function filter_rates( $rates, $package ) {
        $hide_rates = array();
        $hide_instances = array();
        foreach ( DCP_Profiles::all() as $id => $profile ) {
            $rate_id = 'dcp_courier:' . $id;
            // Only an actually available profile rate can trigger hiding.
            if ( 'yes' === $profile['enabled'] && isset( $rates[ $rate_id ] ) &&
                'dcp_courier' === $rates[ $rate_id ]->get_method_id() &&
                DCP_Areas::matches( $profile, $package['destination'] ?? array() ) ) {
                $hide_rates = array_merge( $hide_rates, $profile['hide_rates'] );
                $hide_instances = array_merge( $hide_instances, $profile['hide_instances'] );
            }
        }
        foreach ( $rates as $id => $rate ) {
            if ( 'dcp_courier' === $rate->get_method_id() ) {
                continue;
            }
            $instance = $rate->get_method_id() . ':' . $rate->get_instance_id();
            if ( in_array( (string) $id, $hide_rates, true ) || in_array( $instance, $hide_instances, true ) ) {
                unset( $rates[ $id ] );
            }
        }
        return $rates;
    }
}