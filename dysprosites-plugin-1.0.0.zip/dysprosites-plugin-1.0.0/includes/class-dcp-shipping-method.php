<?php
defined( 'ABSPATH' ) || exit;

/** Global (non-zone) method: one unique checkout rate per matching profile. */
class DCP_Shipping_Method extends WC_Shipping_Method {
    public function __construct( $instance_id = 0 ) {
        $this->id = 'dcp_courier';
        $this->instance_id = 0;
        $this->method_title = 'Δυσπρόσιτες Courier';
        $this->method_description = 'Διαχείριση από WooCommerce → Δυσπρόσιτες Courier. Δεν απαιτείται προσθήκη σε ζώνες.';
        $this->title = $this->method_title;
        $this->enabled = 'yes';
        $this->supports = array();
    }

    public static function weight( $package ) {
        $weight = 0.0;
        foreach ( $package['contents'] ?? array() as $item ) {
            $product = $item['data'] ?? null;
            if ( ! $product || ! $product->needs_shipping() ) {
                continue;
            }
            $weight += max( 0, (float) $product->get_weight() ) * max( 0, (float) ( $item['quantity'] ?? 0 ) );
        }
        return (float) wc_get_weight( $weight, 'kg' );
    }

    public static function cost( $profile, $weight ) {
        // Ignore binary floating point noise at exact kilo boundaries.
        $extra = max( 0, ceil( round( $weight - (float) $profile['base_weight'], 6 ) ) );
        return (float) $profile['base_cost'] + $extra * (float) $profile['additional_cost'];
    }

    /** Entire cart, not the current shipping package. Items are already discounted. */
    public static function cart_amount() {
        $cart = WC()->cart;
        if ( ! $cart ) {
            return null;
        }
        $total = 0.0;
        foreach ( $cart->get_cart() as $item ) {
            if ( ! isset( $item['line_total'], $item['line_tax'] ) || ! is_numeric( $item['line_total'] ) || ! is_numeric( $item['line_tax'] ) ) {
                return null;
            }
            $total += (float) $item['line_total'] + (float) $item['line_tax'];
        }
        return is_finite( $total ) ? round( max( 0, $total ), wc_get_price_decimals() ) : null;
    }

    public static function is_free( $profile, $amount ) {
        $threshold = $profile['free_shipping_threshold'] ?? '';
        return '' !== $threshold && is_numeric( $threshold ) && (float) $threshold >= 0 &&
            null !== $amount && $amount >= (float) $threshold;
    }

    public function calculate_shipping( $package = array() ) {
        $weight = self::weight( $package );
        $amount = self::cart_amount();
        foreach ( DCP_Profiles::all() as $id => $profile ) {
            if ( 'yes' !== $profile['enabled'] || ! DCP_Areas::matches( $profile, $package['destination'] ?? array() ) ) {
                continue;
            }
            $this->tax_status = $profile['tax_status'];
            $free = self::is_free( $profile, $amount );
            $this->add_rate( array(
                'id' => $this->get_rate_id( $id ),
                'label' => $free && '' !== trim( $profile['free_shipping_title'] ?? '' ) ? $profile['free_shipping_title'] : $profile['title'],
                'cost' => $free ? 0 : self::cost( $profile, $weight ),
                'taxes' => $free || 'none' === $profile['tax_status'] ? false : '',
                'calc_tax' => 'per_order',
                'package' => $package,
                'meta_data' => array( 'dcp_profile_id' => $id, 'dcp_courier_name' => $profile['name'] ),
            ) );
        }
    }
}