<?php
defined( 'ABSPATH' ) || exit;

final class DCP_Profiles {
    const OPTION = 'dcp_courier_profiles';

    public static function defaults() {
        return array(
            'id' => '', 'name' => '', 'title' => '', 'enabled' => 'yes', 'country' => 'GR',
            'areas' => '', 'area_generation' => '', 'area_count' => 0, 'base_cost' => '0',
            'base_weight' => '2', 'additional_cost' => '0', 'tax_status' => 'none',
            'free_shipping_threshold' => '', 'free_shipping_title' => '',
            'hide_rates' => array(), 'hide_instances' => array(),
        );
    }

    public static function all() {
        $profiles = get_option( self::OPTION, array() );
        $result = array();
        foreach ( is_array( $profiles ) ? $profiles : array() as $id => $profile ) {
            if ( is_array( $profile ) ) {
                $result[ $id ] = array_merge( self::defaults(), $profile, array( 'id' => (string) $id ) );
                unset( $result[ $id ]['match_mode'], $result[ $id ]['areas'] );
            }
        }
        return $result;
    }

    public static function get( $id ) {
        $all = self::all();
        if ( ! isset( $all[ $id ] ) ) {
            return null;
        }
        $profile = $all[ $id ];
        if ( ! $profile['area_generation'] ) {
            $stored = get_option( self::OPTION, array() );
            $profile['areas'] = $stored[ $id ]['areas'] ?? '';
            return $profile;
        }
        $text = DCP_Area_Store::text( $id, $profile['area_generation'] );
        if ( is_wp_error( $text ) ) {
            return $text;
        }
        $parsed = DCP_Areas::parse( $text );
        if ( $parsed['errors'] || $parsed['skipped'] || count( $parsed['rows'] ) !== (int) $profile['area_count'] ) {
            return new WP_Error( 'database', 'Ο αριθμός των αποθηκευμένων περιοχών δεν συμφωνεί με το προφίλ. Η λίστα δεν φορτώθηκε για να αποφευχθεί απώλεια δεδομένων. Ελέγξτε τη βάση ή επαναφέρετε αντίγραφο ασφαλείας.' );
        }
        $profile['areas'] = $text;
        return $profile;
    }

    public static function save( $id, $raw ) {
        return self::locked( function () use ( $id, $raw ) {
            return self::save_unlocked( $id, $raw );
        } );
    }

    /** Serialize writes across admins; MySQL releases the lock when the connection closes. */
    private static function locked( $callback ) {
        global $wpdb;
        $key = 'dcp_' . md5( $wpdb->prefix . self::OPTION );
        if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $key ) ) ) {
            return new WP_Error( 'busy', 'Η αποθήκευση είναι προσωρινά απασχολημένη. Δοκιμάστε ξανά.' );
        }
        try {
            // Another request may have published while this request waited for the lock.
            wp_cache_delete( self::OPTION, 'options' );
            wp_cache_delete( 'alloptions', 'options' );
            wp_cache_delete( 'notoptions', 'options' );
            return $callback();
        } finally {
            $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $key ) );
        }
    }

    private static function save_unlocked( $id, $raw ) {
        if ( ! DCP_Area_Store::ready() && ! DCP_Area_Store::install() ) {
            return new WP_Error( 'database', 'Δεν είναι διαθέσιμος ο πίνακας περιοχών. Οι παλιές λίστες διατηρούνται.' );
        }
        $all = self::all();
        if ( $id && ! isset( $all[ $id ] ) ) {
            return new WP_Error( 'missing', 'Η εταιρεία δεν βρέθηκε. Ανανεώστε τη σελίδα.' );
        }
        $profile = self::defaults();
        foreach ( array( 'name', 'title', 'country', 'tax_status', 'free_shipping_title' ) as $field ) {
            $profile[ $field ] = sanitize_text_field( $raw[ $field ] ?? $profile[ $field ] );
        }
        if ( '' === $profile['name'] || '' === $profile['title'] ) {
            return new WP_Error( 'name', 'Συμπληρώστε όνομα εταιρείας και τίτλο αποστολής.' );
        }
        $profile['country'] = strtoupper( $profile['country'] );
        $countries = WC()->countries->get_countries();
        if ( ! isset( $countries[ $profile['country'] ] ) ||
            ! in_array( $profile['tax_status'], array( 'taxable', 'none' ), true ) ) {
            return new WP_Error( 'settings', 'Μη έγκυρη χώρα ή φορολογική κατάσταση.' );
        }
        $profile['enabled'] = ( isset( $raw['enabled'] ) && 'yes' === $raw['enabled'] ) ? 'yes' : 'no';
        foreach ( array( 'base_cost', 'base_weight', 'additional_cost', 'free_shipping_threshold' ) as $field ) {
            $input = $raw[ $field ] ?? '';
            if ( 'free_shipping_threshold' === $field && is_scalar( $input ) && '' === trim( (string) $input ) ) {
                $profile[ $field ] = '';
                continue;
            }
            if ( ! is_scalar( $input ) || ! preg_match( '/^(?:\d+(?:[.,]\d*)?|[.,]\d+)$/D', trim( (string) $input ) ) ) {
                return new WP_Error( 'cost', 'Οι χρεώσεις και το βασικό βάρος πρέπει να είναι μη αρνητικοί αριθμοί, χωρίς σύμβολα ή διαχωριστικά χιλιάδων.' );
            }
            $value = wc_format_decimal( str_replace( ',', '.', trim( (string) $input ) ) );
            if ( '' === $value || ! is_numeric( $value ) || ! is_finite( (float) $value ) || (float) $value < 0 ) {
                return new WP_Error( 'cost', 'Οι χρεώσεις και το βασικό βάρος πρέπει να είναι μη αρνητικοί αριθμοί.' );
            }
            $profile[ $field ] = $value;
        }
        $areas = (string) ( $raw['areas'] ?? '' );
        if ( strlen( $areas ) > 2 * 1024 * 1024 ) {
            return new WP_Error( 'size', 'Η λίστα δεν πρέπει να ξεπερνά τα 2 MB.' );
        }
        $parsed = DCP_Areas::parse( $areas );
        if ( $parsed['errors'] ) {
            return new WP_Error( 'areas', implode( ' ', array_slice( $parsed['errors'], 0, 10 ) ) );
        }
        if ( 'yes' === $profile['enabled'] && ! $parsed['rows'] ) {
            return new WP_Error( 'empty', 'Προσθέστε τουλάχιστον μία δυσπρόσιτη περιοχή ή απενεργοποιήστε την εταιρεία.' );
        }
        unset( $profile['areas'] );
        foreach ( array( 'hide_rates', 'hide_instances' ) as $field ) {
            $values = $raw[ $field ] ?? array();
            if ( is_string( $values ) ) {
                $values = preg_split( '/\r\n|\r|\n/', $values );
            }
            $profile[ $field ] = array();
            foreach ( (array) $values as $value ) {
                if ( ! is_scalar( $value ) ) {
                    continue;
                }
                $value = trim( sanitize_text_field( $value ) );
                if ( '' !== $value && 0 !== strpos( $value, 'dcp_courier' ) ) {
                    $profile[ $field ][] = $value;
                }
            }
            $profile[ $field ] = array_values( array_unique( $profile[ $field ] ) );
        }
        $id = $id ?: wp_generate_uuid4();
        $profile['id'] = $id;
        $generation = DCP_Area_Store::stage( $id, $parsed['rows'] );
        if ( is_wp_error( $generation ) ) {
            return $generation;
        }
        $profile['area_generation'] = $generation;
        $profile['area_count'] = count( $parsed['rows'] );
        // Read the raw option so a not-yet-migrated sibling's CSV is never discarded.
        $stored = get_option( self::OPTION, array() );
        $all = is_array( $stored ) ? $stored : array();
        $all[ $id ] = $profile;
        if ( ! update_option( self::OPTION, $all, false ) ) {
            DCP_Area_Store::discard( $id, $generation );
            return new WP_Error( 'database', 'Η αποθήκευση απέτυχε. Η προηγούμενη λίστα παραμένει ενεργή.' );
        }
        DCP_Area_Store::prune( $id, $generation );
        self::invalidate();
        return $id;
    }

    public static function delete( $id ) {
        return self::locked( function () use ( $id ) {
            $all = get_option( self::OPTION, array() );
            if ( ! is_array( $all ) || ! isset( $all[ $id ] ) ) {
                return true;
            }
            unset( $all[ $id ] );
            if ( ! update_option( self::OPTION, $all, false ) ) {
                return new WP_Error( 'database', 'Η διαγραφή απέτυχε. Το προφίλ διατηρήθηκε.' );
            }
            DCP_Area_Store::delete_profile( $id );
            self::invalidate();
            return true;
        } );
    }

    private static function invalidate() {
        update_option( 'dcp_shipping_revision', wp_generate_uuid4(), false );
        if ( class_exists( 'WC_Cache_Helper' ) ) {
            WC_Cache_Helper::get_transient_version( 'shipping', true );
        }
    }

    /** Publish a generation only after all rows have been written and verified. */
    public static function migrate_options() {
        $stored = get_option( self::OPTION, array() );
        $pending = array_filter( is_array( $stored ) ? $stored : array(), function ( $profile ) {
            return is_array( $profile ) && array_key_exists( 'areas', $profile );
        } );
        if ( ! $pending ) {
            return DCP_Area_Store::ready() || DCP_Area_Store::install();
        }
        $result = self::locked( function () {
            if ( ! DCP_Area_Store::ready() && ! DCP_Area_Store::install() ) {
                return false;
            }
            $all = get_option( self::OPTION, array() );
            foreach ( $all as $id => $profile ) {
                if ( ! is_array( $profile ) || ! array_key_exists( 'areas', $profile ) ) {
                    continue;
                }
                $parsed = DCP_Areas::parse( $profile['areas'] );
                // Do not silently lose any legacy row during automatic migration.
                if ( $parsed['errors'] || $parsed['skipped'] || ( 'yes' === ( $profile['enabled'] ?? 'yes' ) && ! $parsed['rows'] ) ) {
                    return false;
                }
                $generation = DCP_Area_Store::stage( $id, $parsed['rows'] );
                if ( is_wp_error( $generation ) ) {
                    return false;
                }
                $next = $all;
                $next[ $id ]['area_generation'] = $generation;
                $next[ $id ]['area_count'] = count( $parsed['rows'] );
                unset( $next[ $id ]['areas'], $next[ $id ]['match_mode'] );
                if ( ! update_option( self::OPTION, $next, false ) ) {
                    DCP_Area_Store::discard( $id, $generation );
                    return false;
                }
                $all = $next;
                DCP_Area_Store::prune( $id, $generation );
                self::invalidate();
            }
            return true;
        } );
        return true === $result;
    }

    public static function legacy_sources() {
        return array( 'custom_elta_courier' => 'ΕΛΤΑ Courier', 'custom_acs' => 'ACS' );
    }

    public static function legacy_imports() {
        $imports = get_option( 'dcp_legacy_imports', array() );
        $imports = is_array( $imports ) ? $imports : array();
        // Compatibility with versions that imported ELTA with a single marker.
        $previous = get_option( 'dcp_legacy_imported', false );
        if ( $previous && ! isset( $imports['custom_elta_courier'] ) ) {
            $imports['custom_elta_courier'] = $previous;
        }
        return $imports;
    }

    public static function migrate_legacy( $source = 'custom_elta_courier' ) {
        $sources = self::legacy_sources();
        $imports = self::legacy_imports();
        if ( ! isset( $sources[ $source ] ) || isset( $imports[ $source ] ) ) {
            return false;
        }
        $old = get_option( 'woocommerce_' . $source . '_settings', array() );
        if ( ! is_array( $old ) || ! $old ) {
            return false;
        }
        $raw = array_merge( self::defaults(), array(
            'name' => $sources[ $source ],
            'title' => $old['title'] ?? 'Δυσπρόσιτες περιοχές με ' . $sources[ $source ],
            'enabled' => $old['enabled'] ?? 'yes',
            'areas' => $old['hard_to_reach_areas'] ?? '',
            'base_cost' => $old['base_cost'] ?? '0',
            'additional_cost' => $old['additional_cost_per_kg'] ?? '0',
        ) );
        $id = self::save( '', $raw );
        if ( is_wp_error( $id ) ) {
            return false;
        }
        $imports[ $source ] = $id;
        update_option( 'dcp_legacy_imports', $imports, false );
        if ( 'custom_elta_courier' === $source ) {
            update_option( 'dcp_legacy_imported', $id, false );
        }
        return true;
    }
}